/*#include <SFML/Window.hpp>
#include <SFML/Graphics.hpp>

using namespace sf;

Texture texture;
Sprite sprite;

int main() {

	texture.loadFromFile("fondo.jpg");
	sprite.setTexture(texture);

	sprite.setPosition(0, 0);
	sprite.setScale(0.8, 0.8);

	sf::RenderWindow App(sf::VideoMode(800, 600, 32),
		"Fondo");


	while (App.isOpen())
	{
		App.clear();

		App.draw(sprite);

		App.display();
	}
	return 0;
}*/