/*#include <SFML/Window.hpp>
#include <SFML/Graphics.hpp>

using namespace sf;

Texture texture1;
Texture texture2;


Sprite sprite1;
Sprite sprite2;

int main() {
    texture1.loadFromFile("chessw.png");
    texture2.loadFromFile("chessb.png");

    sprite1.setTexture(texture1);
    sprite2.setTexture(texture2);

    sprite1.setScale(10, 10);
    sprite2.setScale(10, 10);

    sf::RenderWindow App(sf::VideoMode(800, 800, 32), "Ajedrez");

    bool blanco = true;

    while (App.isOpen()) {
        App.clear();

        for (int y = 0; y < 8; y++) {
            for (int x = 0; x < 8; x++) {
                if (blanco) {
                    sprite1.setPosition(x * 100, y * 100);
                    App.draw(sprite1);
                }
                else {
                    sprite2.setPosition(x * 100, y * 100);
                    App.draw(sprite2);
                }

                blanco = !blanco;
            }

            blanco = !blanco;
        }

        App.display();
    }

    return 0;
}*/